# Episodio · Criterio — mapa de cues

El VO ya está grabado. Estas son las palabras que disparan cada estado
visual. Después de correr `npm run transcribe:criterio`, verificá en el
Studio que cada una haya matcheado; si alguna falla, el visual cae en su
frame de fallback y hay que ajustar el `needle` en el código.

**Palabras marcadas en negrita = cue.** Si al grabar cambiaste alguna
formulación, actualizá el `useCue()` correspondiente, no el frame.

---

## C1 · Arranque — SPLIT — 0:00–0:45

| Cue | Dispara |
|---|---|
| `diez años` | Entra el panel superior: "Todo aviso pide · 10 años de experiencia" |
| `cuarenta y cinco` | Entra el panel inferior en rojo, y el trazo que los une **se parte** |
| `impecable` | Wipe. Entran "Impecable. / Perfecto. / Pulido." en sucesión rápida |
| `descarta` | Wipe. La pregunta que queda abierta |

El hueco en el trazo es todo el bloque. Una balanza habría dicho "una
pesa más" y el argumento no es ese: es que las dos son verdad a la vez.

## C2 · Qué es esto en serio — FULL — 0:45–1:30

| Cue | Dispara |
|---|---|
| `no es información` | "Información acumulada" en muted |
| *(+36f)* | El tachado **se dibuja** encima. El borrado se ve en vivo |
| `error acumulado` | La definición real, en displayXL |
| `nunca perdió un cliente` | Wipe. Las dos columnas de acumulación |
| `plausible` | Wipe. Frase de cierre |

Las columnas son el visual central: izquierda se llena sola, continua e
ilegible de densa; derecha suma pocas marcas y cada una entra de golpe.
**La asimetría de ritmo es el argumento**, no la altura.

## C3 · Lo que cambió de precio — FULL — 1:30–2:30

| Cue | Dispara |
|---|---|
| `tendió a cero` | Se dibujan las dos curvas y el punto de cruce |
| `escaso` | La frase de la mudanza del valor |
| `trampa` | Wipe. "No toda experiencia es criterio" |
| `costumbre` | **Rojo 2/4.** El bloque descartado por el filtro |
| `disparó` | Wipe. Cierre del bloque |

Sin el filtro, este bloque se lee como "la experiencia vale" — que es
exactamente lo que el guion no dice.

## C4 · El absurdo — SPLIT — 2:30–3:45

| Cue | Dispara |
|---|---|
| `lo tira` | Se dibuja la línea de vida productiva (20 → 85) |
| `sesenta y cinco` | **Rojo 3/4.** El tramo descartado se marca en punteado |
| `de vos` | Wipe. El giro: "Te vengo a hablar de vos" |
| `sueldos de guerra` | Wipe. Las dos etiquetas de precio |
| `ingrediente equivocado` | Wipe. Veredicto |

Todo el bloque va a cámara. En voz en off suena a denuncia; a cámara
suena a acusación amable, que es lo que corresponde.

## C5 · La traba y la salida — SPLIT → FULL → SPLIT — 3:45–5:00

| Cue | Dispara |
|---|---|
| `identidad` | "La traba no es capacidad. Es identidad." |
| `veinte dólares` | Contador a USD 20 |
| `caro y lento` | Wipe. El espejo del lado del espectador |
| `desarmados` | **El rostro sale.** Modo FULL. Los dos círculos |
| *(+300f)* | **Rojo 4/4.** Los círculos se solapan y el área común se pinta |
| `último trimestre` | **El rostro vuelve.** Modo SPLIT. Las dos preguntas |

Es el único bloque que cambia de modo por dentro. No es capricho de
layout: marca el único momento del video donde el argumento deja de ser
diagnóstico y pasa a ser salida. El área de solape queda **vacía** a
propósito — lo que va ahí lo pone el espectador.

---

## Presupuesto del acento

Cuatro usos en cinco minutos. Están marcados en el código.

1. **C1** — el corte en 45 años
2. **C3** — "Costumbre"
3. **C4** — el tramo de vida productiva descartado
4. **C5** — el solape de los dos círculos

Los tres primeros son el villano estructural. El cuarto es activación:
es lo único en todo el video que se lee como salida.

## Reparto de modos

| Bloque | Modo | Frames | Tiempo |
|---|---|---|---|
| C1 · Arranque | SPLIT | 1350 | 0:00–0:45 |
| C2 · Qué es | FULL | 1350 | 0:45–1:30 |
| C3 · Precio | FULL | 1800 | 1:30–2:30 |
| C4 · Absurdo | SPLIT | 2250 | 2:30–3:45 |
| C5 · Salida | SPLIT → FULL → SPLIT | 2250 | 3:45–5:00 |

**55% split / 45% full.** Son ~2:45 a cámara, en tres clips:

| Archivo | Cubre | Duración |
|---|---|---|
| `criterio-aroll-1.mp4` | C1 | ~45s |
| `criterio-aroll-2.mp4` | C4 | ~75s |
| `criterio-aroll-3.mp4` | C5 (entra, sale, vuelve) | ~75s |

El tercero se corta solo: el componente maneja la salida y el reingreso
con `exitAt` / `startFrom`, así que grabalo de corrido.

## Puesta en marcha

```bash
npm install
cp tu-vo.wav public/audio/vo-criterio.wav
npm run transcribe:criterio
npm run dev                    # abrir CriterioMaster
npm run render:criterio
```
